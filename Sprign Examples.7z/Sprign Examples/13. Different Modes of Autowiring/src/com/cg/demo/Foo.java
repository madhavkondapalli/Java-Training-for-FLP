package com.cg.demo;

public class Foo {

}
