package com.cg.demo;

public interface DemoBean {
	public MyHelper getMyHelper();
	public void doSomeOperation();
}
