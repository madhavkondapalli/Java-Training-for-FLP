package com.cg.hellospringboot;


import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;



@RestController
@ComponentScan
public class HelloController
{

		@RequestMapping("/")
		public String greeting()
		{
			return "HelloWorld";
		}
	
	
	/*@RequestMapping("/")
	public Message greeting2()
	{
		Message msg=new Message("Hello World inside Message Class");
		return msg;
	}*/
}
