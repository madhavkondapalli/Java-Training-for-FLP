package com.cg.hellospringboot;

public class HellospringbootApplicationTests {

	
	public void contextLoads() {
	}

}
