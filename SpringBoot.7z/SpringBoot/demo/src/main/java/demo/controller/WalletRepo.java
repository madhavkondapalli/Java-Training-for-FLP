package demo.controller;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface WalletRepo extends JpaRepository<Customer, Integer>{
	
//	public boolean save(Customer c);
	@Query(value="SELECT c FROM Customer c JOIN FETCH c.wallet WHERE c.mobileNumber=?1")
	public Customer findOne(String mobileNumber);
	//public boolean update(String mobileNumber,float updatedBalace);

}
