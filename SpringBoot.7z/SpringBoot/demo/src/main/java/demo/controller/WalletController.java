package demo.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@ComponentScan(basePackages="demo.controller")
public class WalletController {

	@Autowired
	private WalletService service;

	@RequestMapping(value="/createCustomer", method=RequestMethod.POST)
	public Customer createCustomer(String name,String mobileNumber,float amount)
	{
		Customer c=service.createAccount(name, mobileNumber, amount);
		System.out.println(c);
		return c;
	}
	@RequestMapping(value="/showBalance", method=RequestMethod.POST)
	public Customer showBalance(String mobileNumber)
	{
		Customer c=service.showBalance(mobileNumber);
		System.out.println(c);
		return c;
	}
	@RequestMapping(value="/deposit", method=RequestMethod.POST)
	public boolean deposit(String mobileNumber,float amount)
	{
		return service.deposit(mobileNumber, amount);

	}

	@RequestMapping(value="/withdraw", method=RequestMethod.POST)
	public boolean withdraw(String mobileNumber,float amount)
	{
		return service.withdraw(mobileNumber, amount);

	}
	
}
