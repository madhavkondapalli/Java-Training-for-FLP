package demo.controller;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service(value="service")
public class WalletServiceIMPL implements WalletService
{
	@Autowired
	private WalletRepo repo;
	
	@Override
	@Transactional
	public Customer createAccount(String name, String mobileNumber, float amount) {
		Wallet w = new Wallet(amount);
		Customer c = new Customer(name, mobileNumber, w);
		System.out.println("in service"+c);
		repo.save(c);
		return c;
	}

	@Override
	public Customer showBalance(String mobileNumber) {
		Customer c = repo.findOne(mobileNumber);
		return c;
	}

	@Override
	@Transactional
	public boolean deposit(String mobileNumber, float amount) {
		// TODO Auto-generated method stub
		Customer c = repo.findOne(mobileNumber);
		Wallet w= c.getWallet();
		float currentBalance=w.getBalance();
		float updatedBalance = currentBalance + amount;
		c.setWallet(w);
		w.setBalance(updatedBalance);
	//	repo.save(c);
		
		return true;
	}

	@Override
	@Transactional
	public boolean withdraw(String mobileNumber, float amount) {
		Customer c = repo.findOne(mobileNumber);
		Wallet w= c.getWallet();

		float currentBalance=w.getBalance();

		if(currentBalance > amount)
		{
			float updatedBalance = currentBalance - amount;

			 c.setWallet(w);
			w.setBalance(updatedBalance);
		//	repo.save(c);
			
			return true;
		}
		return false;
	}

}
